package comanche.fractal;
import java.io.Serializable;

public class Request implements Serializable {
	private static final long serialVersionUID = 1L;
	public String url;
	public String rq;
}