package comanche.fractal;

public interface ILogger {
	void log (String msg);
}