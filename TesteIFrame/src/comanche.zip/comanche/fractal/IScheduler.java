package comanche.fractal;

public interface IScheduler {
	void schedule (Runnable task);
}