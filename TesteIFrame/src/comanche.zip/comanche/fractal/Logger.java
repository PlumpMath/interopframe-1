package comanche.fractal;

public class Logger implements ILogger {
	public void log (String msg) { System.out.println(msg); }
}