package comanche.opencom;

import OpenCOM.IUnknown;

public interface Runner extends IUnknown {
	public void run();
}
